package com.certificateverifier.service;

import com.certificateverifier.blockchain.Block;
import com.certificateverifier.dao.CertificateDAO;
import com.certificateverifier.model.Certificate;
import com.certificateverifier.util.HashUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CertificateService {

    private CertificateDAO certificateDAO;

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public CertificateService() {
        certificateDAO = new CertificateDAO();
    }

    // =========================================================
    // ISSUE CERTIFICATE
    // =========================================================

    public Certificate issueCertificate(
            String studentName,
            String course,
            String college,
            long userId) throws Exception {

        Certificate certificate = new Certificate();

        // -----------------------------------------------------
        // Generate certificate ID
        // -----------------------------------------------------

        String certificateId = generateCertificateId();

        certificate.setCertificateId(certificateId);

        // -----------------------------------------------------
        // Store certificate information
        // -----------------------------------------------------

        certificate.setStudentName(studentName);
        certificate.setCourse(course);
        certificate.setCollege(college);

        // -----------------------------------------------------
        // Generate issue date
        // -----------------------------------------------------

        String issueDate =
                LocalDateTime.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "dd-MM-yyyy"
                                )
                        );

        certificate.setIssueDate(issueDate);

        // -----------------------------------------------------
        // Create certificate data
        // -----------------------------------------------------

        String certificateData =
                certificateId + "|" +
                studentName + "|" +
                course + "|" +
                college + "|" +
                issueDate;

        // -----------------------------------------------------
        // Generate SHA-256 certificate hash
        // -----------------------------------------------------

        String certificateHash =
                HashUtil.sha256(certificateData);

        certificate.setCertificateHash(certificateHash);

        // -----------------------------------------------------
        // Get next persistent blockchain number
        // -----------------------------------------------------

        int blockNumber =
                certificateDAO.getNextBlockNumber();

        // -----------------------------------------------------
        // Get previous blockchain hash
        // -----------------------------------------------------

        String previousHash = "0";

        Certificate latestCertificate =
                certificateDAO.getLatestBlockchainCertificate();

        if (latestCertificate != null &&
                latestCertificate.getBlockHash() != null &&
                !latestCertificate.getBlockHash().isBlank()) {

            previousHash =
                    latestCertificate.getBlockHash();
        }

        // -----------------------------------------------------
        // Generate blockchain timestamp
        // -----------------------------------------------------

        String blockTimestamp =
                LocalDateTime.now().toString();

        // -----------------------------------------------------
        // Create blockchain block
        // -----------------------------------------------------

        Block block =
                new Block(
                        blockNumber,
                        certificateId,
                        certificateHash,
                        blockTimestamp,
                        previousHash
                );

        // -----------------------------------------------------
        // Store blockchain information
        // -----------------------------------------------------

        certificate.setBlockNumber(blockNumber);
        certificate.setBlockTimestamp(blockTimestamp);
        certificate.setBlockHash(block.getBlockHash());
        certificate.setPreviousHash(block.getPreviousHash());

        // -----------------------------------------------------
        // Save certificate with logged-in user ID
        // -----------------------------------------------------

        certificateDAO.saveCertificate(
                certificate,
                userId
        );

        System.out.println(
                "Certificate issued successfully: "
                        + certificateId
        );

        return certificate;
    }

    // =========================================================
    // GET CERTIFICATE
    // =========================================================

    public Certificate getCertificate(
            String certificateId) throws Exception {

        return certificateDAO.getCertificateById(
                certificateId
        );
    }

    // =========================================================
    // GET USER CERTIFICATE COUNT
    // =========================================================

    public int getCertificateCountByUser(
            long userId) throws Exception {

        return certificateDAO.getCertificateCountByUser(
                userId
        );
    }

    // =========================================================
    // CHECK BLOCKCHAIN
    // =========================================================

    public boolean isBlockchainValid()
            throws Exception {

        Certificate latestCertificate =
                certificateDAO.getLatestBlockchainCertificate();

        // No blockchain blocks exist
        if (latestCertificate == null) {
            return true;
        }

        int latestBlockNumber =
                latestCertificate.getBlockNumber();

        String expectedPreviousHash = "0";

        // -----------------------------------------------------
        // Validate every blockchain block
        // -----------------------------------------------------

        for (int blockNumber = 1;
             blockNumber <= latestBlockNumber;
             blockNumber++) {

            Certificate certificate =
                    certificateDAO.getCertificateByBlockNumber(
                            blockNumber
                    );

            // Missing block = broken chain
            if (certificate == null) {
                return false;
            }

            // -------------------------------------------------
            // Validate certificate hash
            // -------------------------------------------------

            String certificateData =
                    certificate.getCertificateId()
                            + "|"
                            + certificate.getStudentName()
                            + "|"
                            + certificate.getCourse()
                            + "|"
                            + certificate.getCollege()
                            + "|"
                            + certificate.getIssueDate();

            String calculatedCertificateHash =
                    HashUtil.sha256(certificateData);

            if (!calculatedCertificateHash.equals(
                    certificate.getCertificateHash()
            )) {
                return false;
            }

            // -------------------------------------------------
            // Validate previous hash
            // -------------------------------------------------

            if (!expectedPreviousHash.equals(
                    certificate.getPreviousHash()
            )) {
                return false;
            }

            // -------------------------------------------------
            // Reconstruct blockchain block
            // -------------------------------------------------

            Block block =
                    new Block(
                            certificate.getBlockNumber(),
                            certificate.getCertificateId(),
                            certificate.getCertificateHash(),
                            certificate.getBlockTimestamp(),
                            certificate.getPreviousHash()
                    );

            // -------------------------------------------------
            // Validate block hash
            // -------------------------------------------------

            if (!block.getBlockHash().equals(
                    certificate.getBlockHash()
            )) {
                return false;
            }

            // -------------------------------------------------
            // Current block becomes previous block
            // -------------------------------------------------

            expectedPreviousHash =
                    certificate.getBlockHash();
        }

        return true;
    }

    // =========================================================
    // CHECK SPECIFIC CERTIFICATE
    // =========================================================

    public boolean isCertificateValid(
            Certificate certificate) throws Exception {

        if (certificate == null) {
            return false;
        }

        // -----------------------------------------------------
        // Validate certificate hash
        // -----------------------------------------------------

        String certificateData =
                certificate.getCertificateId()
                        + "|"
                        + certificate.getStudentName()
                        + "|"
                        + certificate.getCourse()
                        + "|"
                        + certificate.getCollege()
                        + "|"
                        + certificate.getIssueDate();

        String calculatedCertificateHash =
                HashUtil.sha256(certificateData);

        if (!calculatedCertificateHash.equals(
                certificate.getCertificateHash()
        )) {
            return false;
        }

        // -----------------------------------------------------
        // Get blockchain block
        // -----------------------------------------------------

        if (certificate.getBlockNumber() <= 0 ||
                certificate.getBlockTimestamp() == null ||
                certificate.getBlockTimestamp().isBlank()) {

            return false;
        }

        // -----------------------------------------------------
        // Reconstruct block
        // -----------------------------------------------------

        Block block =
                new Block(
                        certificate.getBlockNumber(),
                        certificate.getCertificateId(),
                        certificate.getCertificateHash(),
                        certificate.getBlockTimestamp(),
                        certificate.getPreviousHash()
                );

        // -----------------------------------------------------
        // Validate block hash
        // -----------------------------------------------------

        if (!block.getBlockHash().equals(
                certificate.getBlockHash()
        )) {
            return false;
        }

        // -----------------------------------------------------
        // Validate complete blockchain
        // -----------------------------------------------------

        return isBlockchainValid();
    }

    // =========================================================
    // GENERATE CERTIFICATE ID
    // =========================================================

    private String generateCertificateId()
            throws Exception {

        int nextNumber =
                certificateDAO.getNextCertificateNumber();

        /*
         * Safety check:
         * If the DAO returns a number that is already used,
         * keep increasing it until a free certificate ID is found.
         *
         * This prevents duplicate certificate IDs even if the
         * database count and actual certificate numbers differ.
         */

        while (true) {

            String certificateId =
                    String.format(
                            "CERT-2026-%04d",
                            nextNumber
                    );

            Certificate existingCertificate =
                    certificateDAO.getCertificateById(
                            certificateId
                    );

            if (existingCertificate == null) {
                return certificateId;
            }

            nextNumber++;
        }
    }
}