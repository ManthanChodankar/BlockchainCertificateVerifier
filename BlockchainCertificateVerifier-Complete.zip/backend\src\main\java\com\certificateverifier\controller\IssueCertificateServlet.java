package com.certificateverifier.controller;

import com.certificateverifier.model.Certificate;
import com.certificateverifier.service.CertificateService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet("/issue")
public class IssueCertificateServlet extends HttpServlet {

    private CertificateService certificateService;


    // =========================================================
    // INITIALIZE
    // =========================================================

    @Override
    public void init()
            throws ServletException {

        certificateService =
                new CertificateService();
    }


    // =========================================================
    // ISSUE CERTIFICATE
    // =========================================================

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // -----------------------------------------------------
        // Check login session
        // -----------------------------------------------------

        HttpSession session =
                request.getSession(false);

        if (
                session == null ||
                session.getAttribute("userId") == null
        ) {

            response.sendRedirect(
                    request.getContextPath()
                            + "/login.html"
            );

            return;
        }


        // -----------------------------------------------------
        // Get logged-in user ID
        // -----------------------------------------------------

        Object userIdObject =
                session.getAttribute("userId");

        if (!(userIdObject instanceof Long)) {

            response.sendRedirect(
                    request.getContextPath()
                            + "/login.html"
            );

            return;
        }

        long userId =
                (Long) userIdObject;


        // -----------------------------------------------------
        // Get certificate form data
        // -----------------------------------------------------

        String studentName =
                request.getParameter("studentName");

        String course =
                request.getParameter("course");

        String college =
                request.getParameter("college");


        // -----------------------------------------------------
        // Validate required fields
        // -----------------------------------------------------

        if (
                studentName == null ||
                course == null ||
                college == null ||
                studentName.isBlank() ||
                course.isBlank() ||
                college.isBlank()
        ) {

            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "All certificate fields are required."
            );

            return;
        }


        // -----------------------------------------------------
        // Issue certificate
        // -----------------------------------------------------

        try {

            Certificate certificate =
                    certificateService.issueCertificate(
                            studentName.trim(),
                            course.trim(),
                            college.trim(),
                            userId
                    );


            // -------------------------------------------------
            // Verify certificate object
            // -------------------------------------------------

            if (certificate == null ||
                    certificate.getCertificateId() == null ||
                    certificate.getCertificateHash() == null ||
                    certificate.getBlockHash() == null) {

                response.sendError(
                        HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "Certificate could not be generated."
                );

                return;
            }


            // -------------------------------------------------
            // Redirect to certificate success page
            // -------------------------------------------------

            String redirectUrl =
                    request.getContextPath()
                            + "/certificate-success.html"
                            + "?certificateId="
                            + URLEncoder.encode(
                                    certificate.getCertificateId(),
                                    StandardCharsets.UTF_8
                            )
                            + "&certificateHash="
                            + URLEncoder.encode(
                                    certificate.getCertificateHash(),
                                    StandardCharsets.UTF_8
                            )
                            + "&blockHash="
                            + URLEncoder.encode(
                                    certificate.getBlockHash(),
                                    StandardCharsets.UTF_8
                            );


            response.sendRedirect(
                    redirectUrl
            );

        } catch (Exception e) {

            System.err.println(
                    "Error issuing certificate."
            );

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to issue certificate. Please try again."
            );
        }
    }
}