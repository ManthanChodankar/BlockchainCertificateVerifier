#!/bin/sh
set -eu

: "${DB_URL:?DB_URL is required}"
: "${DB_USER:?DB_USER is required}"
: "${DB_PASSWORD:?DB_PASSWORD is required}"

cat > /usr/local/tomcat/webapps/ROOT/WEB-INF/classes/config.properties <<EOF
db.url=${DB_URL}
db.user=${DB_USER}
db.password=${DB_PASSWORD}
supabase.url=${SUPABASE_URL:-}
supabase.publishable.key=${SUPABASE_PUBLISHABLE_KEY:-}
EOF

server_port="${PORT:-80}"
sed -i "s/port=\"8080\"/port=\"${server_port}\"/" /usr/local/tomcat/conf/server.xml

exec /usr/local/tomcat/bin/catalina.sh run
