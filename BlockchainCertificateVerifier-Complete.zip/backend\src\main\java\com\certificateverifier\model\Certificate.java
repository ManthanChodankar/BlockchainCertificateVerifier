package com.certificateverifier.model;

public class Certificate {

    private String certificateId;
    private String studentName;
    private String course;
    private String college;
    private String issueDate;
    private String certificateHash;
    private String blockHash;
    private String previousHash;

    // Blockchain persistence fields
    private int blockNumber;
    private String blockTimestamp;


    // =========================================================
    // DEFAULT CONSTRUCTOR
    // =========================================================

    public Certificate() {
    }


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public Certificate(
            String certificateId,
            String studentName,
            String course,
            String college,
            String issueDate) {

        this.certificateId = certificateId;
        this.studentName = studentName;
        this.course = course;
        this.college = college;
        this.issueDate = issueDate;
    }


    // =========================================================
    // CERTIFICATE ID
    // =========================================================

    public String getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(
            String certificateId) {

        this.certificateId = certificateId;
    }


    // =========================================================
    // STUDENT NAME
    // =========================================================

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(
            String studentName) {

        this.studentName = studentName;
    }


    // =========================================================
    // COURSE
    // =========================================================

    public String getCourse() {
        return course;
    }

    public void setCourse(
            String course) {

        this.course = course;
    }


    // =========================================================
    // COLLEGE
    // =========================================================

    public String getCollege() {
        return college;
    }

    public void setCollege(
            String college) {

        this.college = college;
    }


    // =========================================================
    // ISSUE DATE
    // =========================================================

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(
            String issueDate) {

        this.issueDate = issueDate;
    }


    // =========================================================
    // CERTIFICATE HASH
    // =========================================================

    public String getCertificateHash() {
        return certificateHash;
    }

    public void setCertificateHash(
            String certificateHash) {

        this.certificateHash = certificateHash;
    }


    // =========================================================
    // BLOCK HASH
    // =========================================================

    public String getBlockHash() {
        return blockHash;
    }

    public void setBlockHash(
            String blockHash) {

        this.blockHash = blockHash;
    }


    // =========================================================
    // PREVIOUS HASH
    // =========================================================

    public String getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(
            String previousHash) {

        this.previousHash = previousHash;
    }


    // =========================================================
    // BLOCK NUMBER
    // =========================================================

    public int getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(
            int blockNumber) {

        this.blockNumber = blockNumber;
    }


    // =========================================================
    // BLOCK TIMESTAMP
    // =========================================================

    public String getBlockTimestamp() {
        return blockTimestamp;
    }

    public void setBlockTimestamp(
            String blockTimestamp) {

        this.blockTimestamp = blockTimestamp;
    }
}