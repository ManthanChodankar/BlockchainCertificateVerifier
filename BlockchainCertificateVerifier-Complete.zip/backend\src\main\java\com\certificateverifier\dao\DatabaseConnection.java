package com.certificateverifier.dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.postgresql.Driver;

public class DatabaseConnection {

    private static final String DB_URL;
    private static final String DB_USER;
    private static final String DB_PASSWORD;

    static {

        Properties properties = new Properties();

        try (InputStream input =
                     DatabaseConnection.class
                             .getClassLoader()
                             .getResourceAsStream("config.properties")) {

            if (input == null) {
                throw new IllegalStateException(
                        "config.properties was not found on the classpath."
                );
            }

            properties.load(input);

            DB_URL = properties.getProperty("db.url");
            DB_USER = properties.getProperty("db.user");
            DB_PASSWORD = properties.getProperty("db.password");

            if (DB_URL == null ||
                    DB_USER == null ||
                    DB_PASSWORD == null ||
                    DB_URL.isBlank() ||
                    DB_USER.isBlank() ||
                    DB_PASSWORD.isBlank()) {

                throw new IllegalStateException(
                        "Database configuration is incomplete."
                );
            }

            System.out.println(
                    "Database configuration loaded successfully."
            );

        } catch (Exception e) {

            System.err.println(
                    "ERROR: Could not load database configuration."
            );

            throw new RuntimeException(
                    "Could not load database configuration.",
                    e
            );
        }
    }

    private DatabaseConnection() {
    }

    public static Connection getConnection()
            throws SQLException {

        Properties connectionProperties =
                new Properties();

        connectionProperties.setProperty(
                "user",
                DB_USER
        );

        connectionProperties.setProperty(
                "password",
                DB_PASSWORD
        );

        Driver driver = new Driver();

        Connection connection =
                driver.connect(
                        DB_URL,
                        connectionProperties
                );

        if (connection == null) {
            throw new SQLException(
                    "PostgreSQL driver could not establish a connection."
            );
        }

        return connection;
    }
}