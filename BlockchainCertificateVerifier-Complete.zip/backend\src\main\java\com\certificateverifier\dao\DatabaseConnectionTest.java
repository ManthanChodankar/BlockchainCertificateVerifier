package com.certificateverifier.dao;

import java.sql.Connection;

public class DatabaseConnectionTest {

    public static void main(String[] args) {

        try {

            // Load PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            System.out.println("PostgreSQL driver loaded successfully!");

            // Connect to Supabase PostgreSQL
            Connection connection =
                    DatabaseConnection.getConnection();

            System.out.println("================================");
            System.out.println("SUPABASE CONNECTION SUCCESSFUL!");
            System.out.println("Database: "
                    + connection.getCatalog());
            System.out.println("================================");

            connection.close();

        } catch (Exception e) {

            System.out.println("================================");
            System.out.println("SUPABASE CONNECTION FAILED!");
            System.out.println("================================");

            e.printStackTrace();
        }
    }
}