package com.certificateverifier.dao;

import com.certificateverifier.model.Certificate;

public class CertificateDAOTest {

    public static void main(String[] args) throws Exception {

        CertificateDAO certificateDAO =
                new CertificateDAO();

        Certificate certificate =
                new Certificate();

        // -----------------------------------------------------
        // Test certificate data
        // -----------------------------------------------------

        certificate.setCertificateId(
                "TEST-CERT-0001"
        );

        certificate.setStudentName(
                "Test Student"
        );

        certificate.setCourse(
                "Computer Engineering"
        );

        certificate.setCollege(
                "Test College"
        );

        certificate.setIssueDate(
                "07-10-2026"
        );

        certificate.setCertificateHash(
                "test-certificate-hash"
        );

        certificate.setBlockHash(
                "test-block-hash"
        );

        certificate.setPreviousHash(
                "0"
        );

        // -----------------------------------------------------
        // Test user ID
        // -----------------------------------------------------

        long userId = 1L;

        // -----------------------------------------------------
        // Save certificate
        // -----------------------------------------------------

        certificateDAO.saveCertificate(
                certificate,
                userId
        );

        System.out.println(
                "CertificateDAO test completed."
        );
    }
}