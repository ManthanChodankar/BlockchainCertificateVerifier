package com.certificateverifier.controller;

import com.certificateverifier.dao.DatabaseConnection;
import com.certificateverifier.util.PasswordUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.regex.Pattern;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    // Strong password requirements:
    // At least 8 characters
    // At least 1 uppercase letter
    // At least 1 lowercase letter
    // At least 1 number
    // At least 1 special character
    private static final Pattern STRONG_PASSWORD_PATTERN =
            Pattern.compile(
                    "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$"
            );

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Check empty fields
        if (fullName == null || email == null ||
                password == null || confirmPassword == null ||
                fullName.isBlank() || email.isBlank() ||
                password.isBlank() || confirmPassword.isBlank()) {

            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "All fields are required."
            );
            return;
        }

        // Clean input
        fullName = fullName.trim();
        email = email.trim().toLowerCase();

        // Basic email format validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {

            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Please enter a valid email address."
            );
            return;
        }

        // Check password match
        if (!password.equals(confirmPassword)) {

            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Passwords do not match."
            );
            return;
        }

        // Strong password validation
        if (!STRONG_PASSWORD_PATTERN.matcher(password).matches()) {

            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Password must contain at least 8 characters, "
                            + "one uppercase letter, one lowercase letter, "
                            + "one number, and one special character."
            );
            return;
        }

        // Hash password securely
        String passwordHash =
                PasswordUtil.hashPassword(password);

        String sql =
                "INSERT INTO public.users " +
                "(full_name, email, password_hash) " +
                "VALUES (?, ?, ?)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, fullName);
            statement.setString(2, email);
            statement.setString(3, passwordHash);

            statement.executeUpdate();

            // Registration successful
            response.sendRedirect(
                    request.getContextPath()
                            + "/login.html?registered=true"
            );

        } catch (Exception e) {

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Registration failed. Email may already be registered."
            );
        }
    }
}