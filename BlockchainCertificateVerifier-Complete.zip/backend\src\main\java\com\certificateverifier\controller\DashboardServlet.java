package com.certificateverifier.controller;

import com.certificateverifier.dao.DatabaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private static class Activity {

        String certificateId;
        String studentName;
        String course;
        Timestamp createdAt;

        Activity(
                String certificateId,
                String studentName,
                String course,
                Timestamp createdAt) {

            this.certificateId = certificateId;
            this.studentName = studentName;
            this.course = course;
            this.createdAt = createdAt;
        }
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath()
                            + "/login.html"
            );

            return;
        }

        long userId;

        try {

            Object userIdObject =
                    session.getAttribute("userId");

            userId =
                    Long.parseLong(
                            userIdObject.toString()
                    );

        } catch (Exception e) {

            response.sendRedirect(
                    request.getContextPath()
                            + "/login.html"
            );

            return;
        }

        int certificateCount = 0;

        List<Activity> activities =
                new ArrayList<>();

        try {

            /*
             * =====================================================
             * 1. GET CERTIFICATE COUNT
             * =====================================================
             */

            String countSql =
                    "SELECT COUNT(*) "
                            + "FROM public.certificates "
                            + "WHERE user_id = ?";

            /*
             * =====================================================
             * 2. GET RECENT CERTIFICATES
             * =====================================================
             */

            String activitySql =
                    "SELECT certificate_id, "
                            + "student_name, "
                            + "course, "
                            + "created_at "
                            + "FROM public.certificates "
                            + "WHERE user_id = ? "
                            + "ORDER BY created_at DESC "
                            + "LIMIT 5";

            try (
                    Connection connection =
                            DatabaseConnection.getConnection();

                    PreparedStatement countStatement =
                            connection.prepareStatement(
                                    countSql
                            );

                    PreparedStatement activityStatement =
                            connection.prepareStatement(
                                    activitySql
                            )
            ) {

                /*
                 * Certificate count
                 */

                countStatement.setLong(
                        1,
                        userId
                );

                try (
                        ResultSet resultSet =
                                countStatement.executeQuery()
                ) {

                    if (resultSet.next()) {

                        certificateCount =
                                resultSet.getInt(1);
                    }
                }

                /*
                 * Recent activity
                 */

                activityStatement.setLong(
                        1,
                        userId
                );

                try (
                        ResultSet resultSet =
                                activityStatement.executeQuery()
                ) {

                    while (resultSet.next()) {

                        activities.add(
                                new Activity(
                                        resultSet.getString(
                                                "certificate_id"
                                        ),
                                        resultSet.getString(
                                                "student_name"
                                        ),
                                        resultSet.getString(
                                                "course"
                                        ),
                                        resultSet.getTimestamp(
                                                "created_at"
                                        )
                                )
                        );
                    }
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            /*
             * Keep the dashboard available even if
             * the activity query fails.
             */
        }

        /*
         * =========================================================
         * LOAD EXISTING DASHBOARD HTML
         * =========================================================
         */

        String dashboardHtml =
                loadDashboardHtml();

        /*
         * =========================================================
         * UPDATE CERTIFICATE COUNT
         * =========================================================
         */

        dashboardHtml =
                updateCertificateCount(
                        dashboardHtml,
                        certificateCount
                );

        /*
         * =========================================================
         * UPDATE RECENT ACTIVITY
         * =========================================================
         */

        dashboardHtml =
                updateRecentActivity(
                        dashboardHtml,
                        activities
                );

        response.setContentType(
                "text/html; charset=UTF-8"
        );

        response.setCharacterEncoding(
                StandardCharsets.UTF_8.name()
        );

        response.getWriter().write(
                dashboardHtml
        );
    }

    // =============================================================
    // LOAD DASHBOARD HTML
    // =============================================================

    private String loadDashboardHtml()
            throws IOException {

        InputStream inputStream =
                getServletContext()
                        .getResourceAsStream(
                                "/dashboard.html"
                        );

        if (inputStream == null) {

            throw new IOException(
                    "dashboard.html could not be found."
            );
        }

        StringBuilder html =
                new StringBuilder();

        try (
                BufferedReader reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        inputStream,
                                        StandardCharsets.UTF_8
                                )
                        )
        ) {

            String line;

            while ((line = reader.readLine()) != null) {

                html.append(line)
                        .append("\n");
            }
        }

        return html.toString();
    }

    // =============================================================
    // UPDATE CERTIFICATE COUNT
    // =============================================================

    private String updateCertificateCount(
            String html,
            int certificateCount) {

        String count =
                String.valueOf(
                        certificateCount
                );

        String updated =
                html.replaceFirst(
                        "(?s)(<span class=\"stat-title\">\\s*"
                                + "Certificates Issued"
                                + "\\s*</span>.*?"
                                + "<div class=\"stat-value\">\\s*)"
                                + "0"
                                + "(\\s*</div>)",
                        "$1"
                                + count
                                + "$2"
                );

        /*
         * Change the status text as well.
         */

        if (certificateCount > 0) {

            updated =
                    updated.replaceFirst(
                            "(?s)(<span class=\"stat-title\">\\s*"
                                    + "Certificates Issued"
                                    + "\\s*</span>.*?"
                                    + "<div class=\"stat-status\">\\s*)"
                                    + "Ready to issue"
                                    + "(\\s*</div>)",
                            "$1"
                                    + "Certificate records available"
                                    + "$2"
                    );

        }

        return updated;
    }

    // =============================================================
    // UPDATE RECENT ACTIVITY
    // =============================================================

    private String updateRecentActivity(
            String html,
            List<Activity> activities) {

        if (activities == null ||
                activities.isEmpty()) {

            return html;
        }

        StringBuilder activityHtml =
                new StringBuilder();

        activityHtml.append(
                "<div class=\"activity-list\" "
                        + "style=\"display:flex;"
                        + "flex-direction:column;"
                        + "gap:12px;"
                        + "padding:18px 0;\">"
        );

        for (Activity activity : activities) {

            String certificateId =
                    escapeHtml(
                            activity.certificateId
                    );

            String studentName =
                    escapeHtml(
                            activity.studentName
                    );

            String course =
                    escapeHtml(
                            activity.course
                    );

            String time =
                    formatTimestamp(
                            activity.createdAt
                    );

            activityHtml.append(

                    "<div style=\"display:flex;"
                            + "align-items:center;"
                            + "gap:14px;"
                            + "padding:15px 16px;"
                            + "border:1px solid "
                            + "rgba(148,163,184,.18);"
                            + "border-radius:12px;"
                            + "background:"
                            + "rgba(15,23,42,.18);\">"

                            + "<div style=\"width:42px;"
                            + "height:42px;"
                            + "min-width:42px;"
                            + "border-radius:11px;"
                            + "display:flex;"
                            + "align-items:center;"
                            + "justify-content:center;"
                            + "background:"
                            + "rgba(37,99,235,.14);"
                            + "font-size:19px;\">"
                            + "📜"
                            + "</div>"

                            + "<div style=\"flex:1;\">"

                            + "<div style=\"font-size:14px;"
                            + "font-weight:700;"
                            + "color:inherit;\">"
                            + "Certificate Issued"
                            + "</div>"

                            + "<div style=\"font-size:12px;"
                            + "margin-top:4px;"
                            + "color:#94a3b8;\">"
                            + certificateId
                            + " • "
                            + studentName
                            + "</div>"

                            + "<div style=\"font-size:11px;"
                            + "margin-top:3px;"
                            + "color:#64748b;\">"
                            + course
                            + "</div>"

                            + "</div>"

                            + "<div style=\"text-align:right;"
                            + "white-space:nowrap;\">"

                            + "<div style=\"font-size:11px;"
                            + "font-weight:700;"
                            + "color:#34d399;\">"
                            + "✓ ISSUED"
                            + "</div>"

                            + "<div style=\"font-size:10px;"
                            + "margin-top:4px;"
                            + "color:#64748b;\">"
                            + time
                            + "</div>"

                            + "</div>"

                            + "</div>"
            );
        }

        activityHtml.append(
                "</div>"
        );

        /*
         * Replace the existing empty-state block.
         */

        return html.replaceFirst(
                "(?s)<div class=\"empty-state\">.*?</div>",
                activityHtml.toString()
        );
    }

    // =============================================================
    // FORMAT TIMESTAMP
    // =============================================================

    private String formatTimestamp(
            Timestamp timestamp) {

        if (timestamp == null) {

            return "Recently";
        }

        return timestamp
                .toLocalDateTime()
                .toString()
                .replace("T", " ");
    }

    // =============================================================
    // HTML ESCAPE
    // =============================================================

    private String escapeHtml(
            String value) {

        if (value == null) {

            return "";
        }

        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}