package com.certificateverifier.controller;

import com.certificateverifier.dao.DatabaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    /*
     * ============================================================
     * SUPABASE CONFIGURATION
     * ============================================================
     */

    private static final String SUPABASE_URL =
            "https://rnnakuxkyywbwqaprnja.supabase.co";

    private static final String SUPABASE_PUBLISHABLE_KEY =
            "sb_publishable_w1nRRFUOVo6dtlPnEy9esw_USa0Ted-";


    /*
     * ============================================================
     * HTTP CLIENT
     * ============================================================
     */

    private final HttpClient httpClient =
            HttpClient.newBuilder()
                    .version(HttpClient.Version.HTTP_1_1)
                    .connectTimeout(Duration.ofSeconds(30))
                    .build();


    /*
     * ============================================================
     * LOGIN
     * ============================================================
     */

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        /*
         * Validate input
         */

        if (email == null ||
                password == null ||
                email.isBlank() ||
                password.isBlank()) {

            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Email and password are required."
            );

            return;
        }

        email = email.trim().toLowerCase();


        try {

            /*
             * ====================================================
             * 1. AUTHENTICATE WITH SUPABASE AUTH
             * ====================================================
             */

            String requestBody =
                    "{"
                            + "\"email\":\""
                            + escapeJson(email)
                            + "\","
                            + "\"password\":\""
                            + escapeJson(password)
                            + "\""
                            + "}";


            HttpRequest authRequest =
                    HttpRequest.newBuilder()
                            .uri(
                                    URI.create(
                                            SUPABASE_URL
                                                    + "/auth/v1/token"
                                                    + "?grant_type=password"
                                    )
                            )
                            .timeout(Duration.ofSeconds(30))
                            .header(
                                    "apikey",
                                    SUPABASE_PUBLISHABLE_KEY
                            )
                            .header(
                                    "Authorization",
                                    "Bearer "
                                            + SUPABASE_PUBLISHABLE_KEY
                            )
                            .header(
                                    "Content-Type",
                                    "application/json"
                            )
                            .header(
                                    "Accept",
                                    "application/json"
                            )
                            .POST(
                                    HttpRequest.BodyPublishers.ofString(
                                            requestBody,
                                            StandardCharsets.UTF_8
                                    )
                            )
                            .build();


            HttpResponse<String> authResponse =
                    httpClient.send(
                            authRequest,
                            HttpResponse.BodyHandlers.ofString(
                                    StandardCharsets.UTF_8
                            )
                    );


            String responseBody =
                    authResponse.body();


            /*
             * ====================================================
             * 2. INVALID LOGIN
             * ====================================================
             */

            if (authResponse.statusCode() != 200) {

                System.out.println(
                        "Supabase login failed. HTTP status: "
                                + authResponse.statusCode()
                );

                System.out.println(
                        "Supabase response: "
                                + responseBody
                );

                response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        "Invalid email or password."
                );

                return;
            }


            /*
             * ====================================================
             * 3. GET SUPABASE USER INFORMATION
             * ====================================================
             */

            String authUserId =
                    extractJsonValue(
                            responseBody,
                            "id"
                    );

            String authEmail =
                    extractJsonValue(
                            responseBody,
                            "email"
                    );


            /*
             * ====================================================
             * 4. SAFETY CHECK
             * ====================================================
             */

            if (authUserId == null ||
                    authUserId.isBlank()) {

                response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        "Unable to authenticate the account."
                );

                return;
            }


            /*
             * ====================================================
             * 5. CONVERT SUPABASE USER ID TO UUID
             * ====================================================
             *
             * Supabase auth_user_id column is UUID.
             * PostgreSQL must receive a UUID, not VARCHAR.
             */

            UUID authUserUUID;

            try {

                authUserUUID =
                        UUID.fromString(authUserId);

            } catch (IllegalArgumentException e) {

                response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        "Invalid authentication user ID."
                );

                return;
            }


            /*
             * ====================================================
             * 6. FIND USER IN public.users
             * ====================================================
             */

            String sql =
                    "SELECT id, full_name, email, role, auth_user_id "
                            + "FROM public.users "
                            + "WHERE auth_user_id = ? "
                            + "OR LOWER(email) = ? "
                            + "LIMIT 1";


            try (
                    Connection connection =
                            DatabaseConnection.getConnection();

                    PreparedStatement statement =
                            connection.prepareStatement(sql)
            ) {

                /*
                 * IMPORTANT:
                 * auth_user_id is UUID in PostgreSQL.
                 */

                statement.setObject(
                        1,
                        authUserUUID
                );

                statement.setString(
                        2,
                        email
                );


                try (
                        ResultSet resultSet =
                                statement.executeQuery()
                ) {

                    /*
                     * =================================================
                     * EXISTING APPLICATION USER
                     * =================================================
                     */

                    if (resultSet.next()) {

                        long userId =
                                resultSet.getLong("id");

                        String fullName =
                                resultSet.getString("full_name");

                        String storedEmail =
                                resultSet.getString("email");

                        String role =
                                resultSet.getString("role");

                        String storedAuthUserId =
                                resultSet.getString("auth_user_id");


                        /*
                         * Connect old application profile
                         * to Supabase Auth user if necessary.
                         */

                        if (storedAuthUserId == null ||
                                storedAuthUserId.isBlank()) {

                            String updateSql =
                                    "UPDATE public.users "
                                            + "SET auth_user_id = ?, "
                                            + "email_verified = TRUE "
                                            + "WHERE id = ?";


                            try (
                                    PreparedStatement updateStatement =
                                            connection.prepareStatement(
                                                    updateSql
                                            )
                            ) {

                                updateStatement.setObject(
                                        1,
                                        authUserUUID
                                );

                                updateStatement.setLong(
                                        2,
                                        userId
                                );

                                updateStatement.executeUpdate();
                            }
                        }


                        /*
                         * =================================================
                         * CREATE JAVA SESSION
                         * =================================================
                         */

                        createSession(
                                request,
                                userId,
                                fullName,
                                storedEmail,
                                role
                        );


                        /*
                         * =================================================
                         * LOGIN SUCCESS
                         * =================================================
                         */

                        response.sendRedirect(
                                request.getContextPath()
                                        + "/dashboard"
                        );

                        return;
                    }
                }
            }


            /*
             * ============================================================
             * 7. AUTH USER EXISTS BUT public.users DOES NOT
             * ============================================================
             *
             * Create application profile automatically.
             */

            String userEmail =
                    authEmail != null &&
                            !authEmail.isBlank()
                            ? authEmail
                            : email;


            String fullName =
                    extractMetadataValue(
                            responseBody,
                            "full_name"
                    );


            if (fullName == null ||
                    fullName.isBlank()) {

                fullName =
                        userEmail.split("@")[0];
            }


            String insertSql =
                    "INSERT INTO public.users "
                            + "(full_name, email, password_hash, "
                            + "email_verified, auth_user_id) "
                            + "VALUES (?, ?, NULL, TRUE, ?) "
                            + "RETURNING id";


            try (
                    Connection connection =
                            DatabaseConnection.getConnection();

                    PreparedStatement statement =
                            connection.prepareStatement(
                                    insertSql
                            )
            ) {

                statement.setString(
                        1,
                        fullName
                );

                statement.setString(
                        2,
                        userEmail.toLowerCase()
                );

                /*
                 * IMPORTANT:
                 * Insert UUID as UUID object.
                 */

                statement.setObject(
                        3,
                        authUserUUID
                );


                try (
                        ResultSet resultSet =
                                statement.executeQuery()
                ) {

                    if (resultSet.next()) {

                        long userId =
                                resultSet.getLong(1);


                        createSession(
                                request,
                                userId,
                                fullName,
                                userEmail,
                                "USER"
                        );


                        response.sendRedirect(
                                request.getContextPath()
                                        + "/dashboard"
                        );

                        return;
                    }
                }
            }


            /*
             * ============================================================
             * PROFILE CREATION FAILED
             * ============================================================
             */

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Account authenticated but user profile could not be created."
            );


        } catch (Exception e) {

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Login failed. Please try again."
            );
        }
    }


    /*
     * ============================================================
     * CREATE JAVA SESSION
     * ============================================================
     */

    private void createSession(
            HttpServletRequest request,
            long userId,
            String userName,
            String userEmail,
            String userRole) {

        /*
         * Prevent session fixation.
         */

        HttpSession oldSession =
                request.getSession(false);

        if (oldSession != null) {
            oldSession.invalidate();
        }


        HttpSession session =
                request.getSession(true);


        session.setAttribute(
                "userId",
                userId
        );

        session.setAttribute(
                "userName",
                userName
        );

        session.setAttribute(
                "userEmail",
                userEmail
        );

        session.setAttribute(
                "userRole",
                userRole != null
                        ? userRole
                        : "USER"
        );


        /*
         * 30-minute inactivity timeout.
         */

        session.setMaxInactiveInterval(
                30 * 60
        );
    }


    /*
     * ============================================================
     * JSON ESCAPE
     * ============================================================
     */

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t");
    }


    /*
     * ============================================================
     * SIMPLE JSON VALUE EXTRACTION
     * ============================================================
     */

    private String extractJsonValue(
            String json,
            String key) {

        if (json == null ||
                key == null) {

            return null;
        }


        String pattern =
                "\"" + Pattern.quote(key)
                        + "\"\\s*:\\s*(?:\"((?:\\\\.|[^\"\\\\])*)\"|(null))";


        Matcher matcher =
                Pattern.compile(
                        pattern
                ).matcher(json);


        if (!matcher.find()) {
            return null;
        }


        if (matcher.group(2) != null) {
            return null;
        }


        String value =
                matcher.group(1);


        if (value == null) {
            return null;
        }


        return value
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t");
    }


    /*
     * ============================================================
     * USER METADATA EXTRACTION
     * ============================================================
     */

    private String extractMetadataValue(
            String json,
            String key) {

        if (json == null ||
                key == null) {

            return null;
        }


        String pattern =
                "\"user_metadata\"\\s*:\\s*\\{[^}]*?"
                        + "\""
                        + Pattern.quote(key)
                        + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"";


        Matcher matcher =
                Pattern.compile(
                        pattern
                ).matcher(json);


        if (!matcher.find()) {
            return null;
        }


        String value =
                matcher.group(1);


        if (value == null) {
            return null;
        }


        return value
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t");
    }
}