const express = require('express');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const app = express();

// Body & Cookie parsing
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser('certichain-cookie-secret-key-2026'));

// Serve public directory
const publicDir = path.join(__dirname, '..', 'public');
app.use(express.static(publicDir));

// Supabase & Database configuration
const DB_CONNECTION_STRING = process.env.DATABASE_URL ||
    'postgresql://postgres.rnnakuxkyywbwqaprnja:saeeKA%40221312@aws-0-ap-southeast-2.pooler.supabase.com:5432/postgres';

const SUPABASE_URL = process.env.SUPABASE_URL || 'https://rnnakuxkyywbwqaprnja.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_w1nRRFUOVo6dtlPnEy9esw_USa0Ted-';
const SESSION_SECRET = process.env.SESSION_SECRET || 'certichain-session-secret-2026';

const pool = new Pool({
    connectionString: DB_CONNECTION_STRING,
    ssl: { rejectUnauthorized: false },
    max: 10,
    idleTimeoutMillis: 30000
});

// ==========================================
// SESSION MANAGEMENT (Stateless HMAC Cookie)
// ==========================================
function createSessionToken(user) {
    const payload = {
        userId: user.userId,
        userName: user.userName,
        userEmail: user.userEmail,
        userRole: user.userRole || 'USER',
        exp: Date.now() + 30 * 60 * 1000 // 30 mins
    };
    const jsonStr = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const signature = crypto.createHmac('sha256', SESSION_SECRET).update(jsonStr).digest('base64url');
    return `${jsonStr}.${signature}`;
}

function verifySessionToken(token) {
    if (!token || typeof token !== 'string') return null;
    const parts = token.split('.');
    if (parts.length !== 2) return null;
    const [jsonStr, signature] = parts;
    const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(jsonStr).digest('base64url');
    if (signature !== expectedSig) return null;
    try {
        const payload = JSON.parse(Buffer.from(jsonStr, 'base64url').toString('utf8'));
        if (payload.exp && Date.now() > payload.exp) return null;
        return payload;
    } catch {
        return null;
    }
}

function authMiddleware(req, res, next) {
    const token = req.cookies.certichain_session;
    const session = verifySessionToken(token);
    if (!session) {
        return res.redirect('/login.html');
    }
    // Refresh token expiry
    const newToken = createSessionToken(session);
    res.cookie('certichain_session', newToken, {
        httpOnly: true,
        maxAge: 30 * 60 * 1000,
        sameSite: 'lax',
        path: '/'
    });
    req.user = session;
    next();
}

// ==========================================
// PASSWORD UTILITIES (PBKDF2 SHA-256)
// ==========================================
function hashPassword(password) {
    const salt = crypto.randomBytes(16);
    const hash = crypto.pbkdf2Sync(password, salt, 65536, 32, 'sha256');
    return `${salt.toString('base64')}:${hash.toString('base64')}`;
}

function verifyPassword(password, storedPassword) {
    if (!storedPassword || typeof storedPassword !== 'string') return false;
    const parts = storedPassword.split(':');
    if (parts.length !== 2) return false;
    try {
        const salt = Buffer.from(parts[0], 'base64');
        const storedHash = Buffer.from(parts[1], 'base64');
        const computedHash = crypto.pbkdf2Sync(password, salt, 65536, 32, 'sha256');
        return crypto.timingSafeEqual(storedHash, computedHash);
    } catch {
        return false;
    }
}

function sha256(data) {
    return crypto.createHash('sha256').update(data, 'utf8').digest('hex');
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// ==========================================
// ROUTES: ROOT & AUTH
// ==========================================
app.get(['/', '/index.html'], (req, res) => {
    res.redirect('/login.html');
});

// Login Handler
const handleLogin = async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password || !email.trim() || !password.trim()) {
        return res.status(400).send('Email and password are required.');
    }

    const cleanEmail = email.trim().toLowerCase();

    try {
        // 1. Try Supabase Auth API
        let authenticated = false;
        let authUserUUID = null;
        let authEmail = cleanEmail;
        let fullName = cleanEmail.split('@')[0];

        try {
            const authRes = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
                method: 'POST',
                headers: {
                    'apikey': SUPABASE_PUBLISHABLE_KEY,
                    'Authorization': `Bearer ${SUPABASE_PUBLISHABLE_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email: cleanEmail, password: password })
            });

            if (authRes.ok) {
                const authData = await authRes.json();
                if (authData.user && authData.user.id) {
                    authenticated = true;
                    authUserUUID = authData.user.id;
                    authEmail = authData.user.email || cleanEmail;
                    if (authData.user.user_metadata && authData.user.user_metadata.full_name) {
                        fullName = authData.user.user_metadata.full_name;
                    }
                }
            }
        } catch (authErr) {
            console.error('Supabase auth request failed, trying local DB fallback:', authErr.message);
        }

        // 2. Query public.users
        let client = await pool.connect();
        try {
            let userResult;
            if (authUserUUID) {
                userResult = await client.query(
                    'SELECT id, full_name, email, role, auth_user_id FROM public.users WHERE auth_user_id = $1 OR LOWER(email) = $2 LIMIT 1',
                    [authUserUUID, cleanEmail]
                );
            } else {
                userResult = await client.query(
                    'SELECT id, full_name, email, role, password_hash, auth_user_id FROM public.users WHERE LOWER(email) = $1 LIMIT 1',
                    [cleanEmail]
                );
            }

            if (userResult.rows.length > 0) {
                const user = userResult.rows[0];

                if (!authenticated) {
                    // Check local password hash
                    if (user.password_hash && verifyPassword(password, user.password_hash)) {
                        authenticated = true;
                    }
                }

                if (!authenticated) {
                    return res.status(401).send('Invalid email or password.');
                }

                // If authenticated with Supabase Auth, ensure auth_user_id is updated
                if (authUserUUID && (!user.auth_user_id || user.auth_user_id !== authUserUUID)) {
                    await client.query(
                        'UPDATE public.users SET auth_user_id = $1, email_verified = TRUE WHERE id = $2',
                        [authUserUUID, user.id]
                    );
                }

                const token = createSessionToken({
                    userId: user.id,
                    userName: user.full_name || fullName,
                    userEmail: user.email,
                    userRole: user.role || 'USER'
                });

                res.cookie('certichain_session', token, {
                    httpOnly: true,
                    maxAge: 30 * 60 * 1000,
                    sameSite: 'lax',
                    path: '/'
                });

                return res.redirect('/dashboard');
            } else {
                // If Supabase authenticated but user not in public.users yet, create profile
                if (authenticated && authUserUUID) {
                    const insertRes = await client.query(
                        'INSERT INTO public.users (full_name, email, password_hash, email_verified, auth_user_id) VALUES ($1, $2, NULL, TRUE, $3) RETURNING id',
                        [fullName, authEmail.toLowerCase(), authUserUUID]
                    );
                    const newUserId = insertRes.rows[0].id;
                    const token = createSessionToken({
                        userId: newUserId,
                        userName: fullName,
                        userEmail: authEmail,
                        userRole: 'USER'
                    });

                    res.cookie('certichain_session', token, {
                        httpOnly: true,
                        maxAge: 30 * 60 * 1000,
                        sameSite: 'lax',
                        path: '/'
                    });

                    return res.redirect('/dashboard');
                } else {
                    return res.status(401).send('Invalid email or password.');
                }
            }
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Login error:', err);
        return res.status(500).send('Login failed. Please try again.');
    }
};

app.post(['/login', '/BlockchainCertificateVerifier/login'], handleLogin);

// Register Handler
const handleRegister = async (req, res) => {
    const { fullName, email, password, confirmPassword } = req.body;
    if (!fullName || !email || !password || !confirmPassword ||
        !fullName.trim() || !email.trim() || !password.trim()) {
        return res.status(400).send('All fields are required.');
    }

    const cleanName = fullName.trim();
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail.match(/^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$/)) {
        return res.status(400).send('Please enter a valid email address.');
    }

    if (password !== confirmPassword) {
        return res.status(400).send('Passwords do not match.');
    }

    const strongPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
    if (!strongPattern.test(password)) {
        return res.status(400).send('Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character.');
    }

    try {
        const passwordHash = hashPassword(password);
        const client = await pool.connect();
        try {
            await client.query(
                'INSERT INTO public.users (full_name, email, password_hash) VALUES ($1, $2, $3)',
                [cleanName, cleanEmail, passwordHash]
            );
            return res.redirect('/login.html?registered=true');
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Registration error:', err);
        return res.status(500).send('Registration failed. Email may already be registered.');
    }
};

app.post(['/register', '/BlockchainCertificateVerifier/register'], handleRegister);

// Logout Handler
const handleLogout = (req, res) => {
    res.clearCookie('certichain_session', { path: '/' });
    res.redirect('/login.html');
};

app.get(['/logout', '/BlockchainCertificateVerifier/logout'], handleLogout);

// ==========================================
// ROUTE: DASHBOARD
// ==========================================
const handleDashboard = async (req, res) => {
    const userId = req.user.userId;

    let certificateCount = 0;
    let activities = [];

    try {
        const client = await pool.connect();
        try {
            const countRes = await client.query('SELECT COUNT(*) FROM public.certificates WHERE user_id = $1', [userId]);
            if (countRes.rows.length > 0) {
                certificateCount = parseInt(countRes.rows[0].count, 10) || 0;
            }

            const actRes = await client.query(
                'SELECT certificate_id, student_name, course, created_at FROM public.certificates WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5',
                [userId]
            );
            activities = actRes.rows;
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Dashboard data error:', err);
    }

    try {
        const templatePath = path.join(publicDir, 'dashboard.html');
        let html = fs.readFileSync(templatePath, 'utf8');

        // Update count
        html = html.replace(
            /(<span class="stat-title">\s*Certificates Issued\s*<\/span>[\s\S]*?<div class="stat-value">\s*)0(\s*<\/div>)/,
            `$1${certificateCount}$2`
        );

        if (certificateCount > 0) {
            html = html.replace(
                /(<span class="stat-title">\s*Certificates Issued\s*<\/span>[\s\S]*?<div class="stat-status">\s*)Ready to issue(\s*<\/div>)/,
                '$1Certificate records available$2'
            );
        }

        // Update activities
        if (activities && activities.length > 0) {
            let actHtml = '<div class="activity-list" style="display:flex;flex-direction:column;gap:12px;padding:18px 0;">';
            for (const act of activities) {
                const cId = escapeHtml(act.certificate_id);
                const sName = escapeHtml(act.student_name);
                const crs = escapeHtml(act.course);
                const timeStr = act.created_at ? new Date(act.created_at).toLocaleString() : 'Recently';

                actHtml += `
                    <div style="display:flex;align-items:center;gap:14px;padding:15px 16px;border:1px solid rgba(148,163,184,.18);border-radius:12px;background:rgba(15,23,42,.18);">
                        <div style="width:42px;height:42px;min-width:42px;border-radius:11px;display:flex;align-items:center;justify-content:center;background:rgba(37,99,235,.14);font-size:19px;">📜</div>
                        <div style="flex:1;">
                            <div style="font-size:14px;font-weight:700;color:inherit;">Certificate Issued</div>
                            <div style="font-size:12px;margin-top:4px;color:#94a3b8;">${cId} • ${sName}</div>
                            <div style="font-size:11px;margin-top:3px;color:#64748b;">${crs}</div>
                        </div>
                        <div style="text-align:right;white-space:nowrap;">
                            <div style="font-size:11px;font-weight:700;color:#34d399;">✓ ISSUED</div>
                            <div style="font-size:10px;margin-top:4px;color:#64748b;">${timeStr}</div>
                        </div>
                    </div>
                `;
            }
            actHtml += '</div>';

            html = html.replace(/<div class="empty-state">[\s\S]*?<\/div>/, actHtml);
        }

        res.setHeader('Content-Type', 'text/html; charset=UTF-8');
        return res.send(html);
    } catch (err) {
        console.error('Error rendering dashboard:', err);
        return res.status(500).send('Unable to load dashboard.');
    }
};

app.get(['/dashboard', '/dashboard.html', '/BlockchainCertificateVerifier/dashboard'], authMiddleware, handleDashboard);

// ==========================================
// ROUTE: ISSUE CERTIFICATE
// ==========================================
const handleIssue = async (req, res) => {
    const userId = req.user.userId;
    const { studentName, course, college } = req.body;

    if (!studentName || !course || !college ||
        !studentName.trim() || !course.trim() || !college.trim()) {
        return res.status(400).send('All certificate fields are required.');
    }

    const sName = studentName.trim();
    const crs = course.trim();
    const clg = college.trim();

    try {
        const client = await pool.connect();
        try {
            // Next certificate number
            const nextNumRes = await client.query(
                `SELECT COALESCE(MAX(CAST(SUBSTRING(certificate_id FROM 11) AS INTEGER)), 0) + 1 AS next_number
                 FROM public.certificates WHERE certificate_id LIKE 'CERT-2026-%'`
            );
            let nextNum = nextNumRes.rows[0].next_number || 1;

            let certificateId = '';
            while (true) {
                certificateId = `CERT-2026-${String(nextNum).padStart(4, '0')}`;
                const checkRes = await client.query('SELECT 1 FROM public.certificates WHERE certificate_id = $1', [certificateId]);
                if (checkRes.rows.length === 0) break;
                nextNum++;
            }

            // Issue Date: DD-MM-YYYY
            const now = new Date();
            const day = String(now.getDate()).padStart(2, '0');
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const year = now.getFullYear();
            const issueDate = `${day}-${month}-${year}`;

            // Certificate Hash
            const certData = `${certificateId}|${sName}|${crs}|${clg}|${issueDate}`;
            const certificateHash = sha256(certData);

            // Block Number
            const blockNumRes = await client.query(
                'SELECT COALESCE(MAX(block_number), 0) + 1 AS next_block_number FROM public.certificates WHERE block_number IS NOT NULL'
            );
            const blockNumber = blockNumRes.rows[0].next_block_number || 1;

            // Previous Hash
            let previousHash = '0';
            const latestCertRes = await client.query(
                'SELECT block_hash FROM public.certificates WHERE block_number IS NOT NULL ORDER BY block_number DESC LIMIT 1'
            );
            if (latestCertRes.rows.length > 0 && latestCertRes.rows[0].block_hash) {
                previousHash = latestCertRes.rows[0].block_hash;
            }

            // Block Timestamp & Hash
            const blockTimestamp = now.toISOString();
            const blockData = `${blockNumber}${certificateId}${certificateHash}${blockTimestamp}${previousHash}`;
            const blockHash = sha256(blockData);

            // Save certificate
            await client.query(
                `INSERT INTO public.certificates 
                 (certificate_id, student_name, course, college, issue_date, certificate_hash, block_hash, previous_hash, block_number, block_timestamp, user_id)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
                [certificateId, sName, crs, clg, issueDate, certificateHash, blockHash, previousHash, blockNumber, blockTimestamp, userId]
            );

            const redirectUrl = `/certificate-success.html?certificateId=${encodeURIComponent(certificateId)}&certificateHash=${encodeURIComponent(certificateHash)}&blockHash=${encodeURIComponent(blockHash)}`;
            return res.redirect(redirectUrl);
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Issue certificate error:', err);
        return res.status(500).send('Unable to issue certificate. Please try again.');
    }
};

app.post(['/issue', '/BlockchainCertificateVerifier/issue'], authMiddleware, handleIssue);

// ==========================================
// ROUTE: VERIFY CERTIFICATE
// ==========================================
function buildMessagePage(title, message, success = false) {
    const icon = success ? '✓' : '×';
    const color = success ? '#16a34a' : '#dc2626';

    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)} | CertiChain</title>
<style>
:root{--bg:#f4f6f9;--surface:#ffffff;--text:#172033;--secondary:#667085;--border:#e2e6ec;--header:#ffffff;}
body.dark-theme{--bg:#0b1120;--surface:#111827;--text:#f1f5f9;--secondary:#a7b1c2;--border:#263247;--header:#0f172a;}
*{box-sizing:border-box;}
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}
.header{height:76px;background:var(--header);border-bottom:1px solid var(--border);display:flex;align-items:center;}
.header-inner{width:100%;max-width:1180px;margin:auto;padding:0 28px;display:flex;justify-content:space-between;align-items:center;}
.brand{text-decoration:none;color:var(--text);font-size:23px;font-weight:700;}
.brand-mark{display:inline-flex;width:36px;height:36px;margin-right:10px;border-radius:9px;background:#2563eb;color:white;align-items:center;justify-content:center;}
.theme-toggle{width:40px;height:40px;border:1px solid var(--border);background:var(--surface);border-radius:9px;cursor:pointer;}
.page{min-height:calc(100vh - 76px);display:flex;align-items:center;justify-content:center;padding:30px;}
.card{max-width:700px;width:100%;background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:55px 40px;text-align:center;box-shadow:0 12px 35px rgba(15,23,42,.08);}
.icon{width:72px;height:72px;margin:0 auto 22px;border-radius:50%;background:${color}22;color:${color};font-size:42px;display:flex;align-items:center;justify-content:center;font-weight:700;}
h1{margin:0 0 12px;font-size:32px;}
p{color:var(--secondary);font-size:16px;line-height:1.7;margin:0;}
</style>
</head>
<body>
<header class="header">
<div class="header-inner">
<a class="brand" href="/dashboard"><span class="brand-mark">C</span>CertiChain</a>
<button class="theme-toggle" id="themeToggle">🌙</button>
</div>
</header>
<main class="page">
<div class="card">
<div class="icon">${icon}</div>
<h1>${escapeHtml(title)}</h1>
<p>${message}</p>
<div style="margin-top:28px;"><a href="/verify.html" style="display:inline-block;padding:11px 22px;background:#2563eb;color:#fff;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;">Verify Another Certificate</a></div>
</div>
</main>
<script>
const savedTheme = localStorage.getItem('certichain-theme');
if(savedTheme === 'dark'){ document.body.classList.add('dark-theme'); }
const toggle = document.getElementById('themeToggle');
toggle.textContent = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';
toggle.addEventListener('click',function(){
  document.body.classList.toggle('dark-theme');
  const dark = document.body.classList.contains('dark-theme');
  localStorage.setItem('certichain-theme', dark ? 'dark' : 'light');
  toggle.textContent = dark ? '☀️' : '🌙';
});
</script>
</body>
</html>`;
}

function buildVerifiedPage(cert) {
    const detailRow = (label, val, isHash = false) => `
        <div class="row">
            <div class="label">${escapeHtml(label)}</div>
            <div class="${isHash ? 'value hash-value' : 'value'}">${escapeHtml(val || 'Not available')}</div>
        </div>
    `;

    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Certificate Verified | CertiChain</title>
<style>
:root{--bg:#f4f6f9;--surface:#ffffff;--surface-soft:#f8fafc;--text:#172033;--text-secondary:#667085;--border:#e2e6ec;--primary:#2563eb;--success:#16a34a;--success-bg:#ecfdf3;--header:#ffffff;--shadow:0 12px 35px rgba(15,23,42,.08);}
body.dark-theme{--bg:#0b1120;--surface:#111827;--surface-soft:#172033;--text:#f1f5f9;--text-secondary:#a7b1c2;--border:#263247;--primary:#3b82f6;--success:#22c55e;--success-bg:#10271b;--header:#0f172a;--shadow:0 18px 45px rgba(0,0,0,.28);}
*{box-sizing:border-box;}
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;transition:background .25s ease,color .25s ease;}
.header{height:76px;background:var(--header);border-bottom:1px solid var(--border);display:flex;align-items:center;}
.header-inner{width:100%;max-width:1180px;margin:auto;padding:0 28px;display:flex;align-items:center;justify-content:space-between;}
.brand{display:flex;align-items:center;gap:11px;text-decoration:none;color:var(--text);font-size:23px;font-weight:700;}
.brand-mark{width:36px;height:36px;border-radius:9px;background:var(--primary);color:white;display:flex;align-items:center;justify-content:center;font-size:19px;font-weight:700;}
.nav{display:flex;align-items:center;gap:28px;}
.nav a{color:var(--text-secondary);text-decoration:none;font-size:14px;font-weight:600;}
.nav a:hover{color:var(--primary);}
.theme-toggle{width:40px;height:40px;border:1px solid var(--border);background:var(--surface);color:var(--text);border-radius:9px;cursor:pointer;font-size:17px;}
.page{max-width:900px;margin:auto;padding:60px 24px 80px;}
.status-header{text-align:center;margin-bottom:34px;}
.status-icon{width:72px;height:72px;margin:0 auto 20px;border-radius:50%;background:var(--success-bg);color:var(--success);display:flex;align-items:center;justify-content:center;font-size:38px;font-weight:700;}
.status-header h1{margin:0 0 10px;font-size:34px;}
.status-header p{margin:0;color:var(--text-secondary);font-size:16px;line-height:1.6;}
.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:34px;}
.verified-banner{display:flex;align-items:center;gap:12px;padding:16px 18px;margin-bottom:25px;border:1px solid rgba(22,163,74,.25);background:var(--success-bg);border-radius:12px;color:var(--success);font-size:15px;font-weight:700;}
.verified-dot{width:9px;height:9px;border-radius:50%;background:var(--success);}
.details{display:grid;gap:12px;}
.row{padding:18px;background:var(--surface-soft);border:1px solid var(--border);border-radius:10px;}
.label{font-size:12px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--text-secondary);margin-bottom:7px;}
.value{font-size:15px;font-weight:600;color:var(--text);line-height:1.5;word-break:break-word;}
.hash-value{font-family:'Courier New',monospace;font-size:13px;line-height:1.6;word-break:break-all;}
.footer-note{margin-top:25px;padding:16px;border-radius:10px;background:var(--surface-soft);border:1px solid var(--border);color:var(--text-secondary);font-size:13px;line-height:1.6;text-align:center;}
@media(max-width:700px){.nav a{display:none;}.page{padding:40px 15px 60px;}.card{padding:20px;}}
</style>
</head>
<body>
<header class="header">
<div class="header-inner">
<a class="brand" href="/dashboard"><span class="brand-mark">C</span>CertiChain</a>
<nav class="nav">
<a href="/dashboard">Home</a>
<a href="/issue.html">Issue Certificate</a>
<a href="/verify.html">Verify</a>
<button type="button" class="theme-toggle" id="themeToggle">🌙</button>
</nav>
</div>
</header>
<main class="page">
<div class="status-header">
<div class="status-icon">✓</div>
<h1>Certificate Verified</h1>
<p>This certificate is authentic and the blockchain integrity check passed.</p>
</div>
<div class="card">
<div class="verified-banner">
<span class="verified-dot"></span>
Certificate authenticity verified successfully
</div>
<div class="details">
${detailRow('Certificate ID', cert.certificate_id)}
${detailRow('Student Name', cert.student_name)}
${detailRow('Course', cert.course)}
${detailRow('College', cert.college)}
${detailRow('Issue Date', cert.issue_date)}
${detailRow('Certificate Hash', cert.certificate_hash, true)}
${detailRow('Blockchain Block Hash', cert.block_hash, true)}
${detailRow('Previous Block Hash', cert.previous_hash, true)}
${detailRow('Block Number', String(cert.block_number))}
${detailRow('Block Timestamp', cert.block_timestamp)}
</div>
<div class="footer-note">
CertiChain verified the certificate using SHA-256 hashing and blockchain integrity validation.
</div>
</div>
</main>
<script>
const savedTheme = localStorage.getItem('certichain-theme');
if(savedTheme === 'dark'){ document.body.classList.add('dark-theme'); }
const toggle = document.getElementById('themeToggle');
toggle.textContent = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';
toggle.addEventListener('click', function(){
  document.body.classList.toggle('dark-theme');
  const dark = document.body.classList.contains('dark-theme');
  localStorage.setItem('certichain-theme', dark ? 'dark' : 'light');
  toggle.textContent = dark ? '☀️' : '🌙';
});
</script>
</body>
</html>`;
}

const handleVerify = async (req, res) => {
    let certId = req.query.id || req.query.certificateId;
    if (!certId || !certId.trim()) {
        return res.send(buildMessagePage('Certificate ID Required', 'Please provide a valid Certificate ID.'));
    }

    certId = certId.trim();

    try {
        const client = await pool.connect();
        try {
            const certRes = await client.query('SELECT * FROM public.certificates WHERE certificate_id = $1', [certId]);
            if (certRes.rows.length === 0) {
                return res.send(buildMessagePage('Certificate Not Found', `The certificate ID <b>${escapeHtml(certId)}</b> does not exist. Please check the Certificate ID and try again.`));
            }

            const cert = certRes.rows[0];

            // 1. Verify individual certificate hash
            const certData = `${cert.certificate_id}|${cert.student_name}|${cert.course}|${cert.college}|${cert.issue_date}`;
            const expectedCertHash = sha256(certData);
            const isCertValid = (expectedCertHash === cert.certificate_hash);

            // 2. Verify individual block hash
            const blockData = `${cert.block_number}${cert.certificate_id}${cert.certificate_hash}${cert.block_timestamp}${cert.previous_hash}`;
            const expectedBlockHash = sha256(blockData);
            const isBlockValid = (expectedBlockHash === cert.block_hash);

            // 3. Verify entire blockchain chain
            let isChainValid = true;
            const chainRes = await client.query('SELECT * FROM public.certificates WHERE block_number IS NOT NULL ORDER BY block_number ASC');
            let expectedPrevHash = '0';

            for (const b of chainRes.rows) {
                const bCertData = `${b.certificate_id}|${b.student_name}|${b.course}|${b.college}|${b.issue_date}`;
                if (sha256(bCertData) !== b.certificate_hash) {
                    isChainValid = false;
                    break;
                }
                if (b.previous_hash !== expectedPrevHash) {
                    isChainValid = false;
                    break;
                }
                const bBlockData = `${b.block_number}${b.certificate_id}${b.certificate_hash}${b.block_timestamp}${b.previous_hash}`;
                if (sha256(bBlockData) !== b.block_hash) {
                    isChainValid = false;
                    break;
                }
                expectedPrevHash = b.block_hash;
            }

            if (isCertValid && isBlockValid && isChainValid) {
                return res.send(buildVerifiedPage(cert));
            } else {
                return res.send(buildMessagePage('Verification Failed', 'The certificate was found, but its cryptographic or blockchain integrity check failed. The certificate should not be considered valid.'));
            }
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Verify error:', err);
        return res.send(buildMessagePage('Verification Error', 'An error occurred while verifying the certificate. Please try again.'));
    }
};

app.get(['/verify', '/BlockchainCertificateVerifier/verify'], handleVerify);

// Fallback: 404
app.use((req, res) => {
    res.status(404).send('Page not found');
});

// Export Express app for Vercel Serverless Function
module.exports = app;

if (process.env.NODE_ENV !== 'production' && !process.env.VERCEL) {
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
        console.log(`Server running at http://localhost:${PORT}`);
    });
}
