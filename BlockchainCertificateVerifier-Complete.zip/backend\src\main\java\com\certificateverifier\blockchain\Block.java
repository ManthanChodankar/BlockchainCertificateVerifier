package com.certificateverifier.blockchain;

import com.certificateverifier.util.HashUtil;

public class Block {

    private int blockNumber;
    private String certificateId;
    private String certificateHash;
    private String timestamp;
    private String previousHash;
    private String blockHash;

    public Block(int blockNumber, String certificateId, String certificateHash,
                 String timestamp, String previousHash) {

        this.blockNumber = blockNumber;
        this.certificateId = certificateId;
        this.certificateHash = certificateHash;
        this.timestamp = timestamp;
        this.previousHash = previousHash;

        this.blockHash = calculateHash();
    }

    public String calculateHash() {

        String data = blockNumber
                + certificateId
                + certificateHash
                + timestamp
                + previousHash;

        return HashUtil.sha256(data);
    }

    public int getBlockNumber() {
        return blockNumber;
    }

    public String getCertificateId() {
        return certificateId;
    }

    public String getCertificateHash() {
        return certificateHash;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public String getBlockHash() {
        return blockHash;
    }
}