package com.certificateverifier.dao;

import com.certificateverifier.model.Certificate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CertificateDAO {

    // =========================================================
    // SAVE CERTIFICATE
    // =========================================================

    public void saveCertificate(
            Certificate certificate,
            long userId) throws Exception {

        String sql =
                "INSERT INTO public.certificates " +
                "(certificate_id, student_name, course, college, " +
                "issue_date, certificate_hash, block_hash, " +
                "previous_hash, block_number, block_timestamp, " +
                "user_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    certificate.getCertificateId()
            );

            statement.setString(
                    2,
                    certificate.getStudentName()
            );

            statement.setString(
                    3,
                    certificate.getCourse()
            );

            statement.setString(
                    4,
                    certificate.getCollege()
            );

            statement.setString(
                    5,
                    certificate.getIssueDate()
            );

            statement.setString(
                    6,
                    certificate.getCertificateHash()
            );

            statement.setString(
                    7,
                    certificate.getBlockHash()
            );

            statement.setString(
                    8,
                    certificate.getPreviousHash()
            );

            statement.setInt(
                    9,
                    certificate.getBlockNumber()
            );

            statement.setString(
                    10,
                    certificate.getBlockTimestamp()
            );

            statement.setLong(
                    11,
                    userId
            );

            statement.executeUpdate();

            System.out.println(
                    "Certificate saved to Supabase successfully!"
            );
        }
    }


    // =========================================================
    // GET CERTIFICATE BY ID
    // =========================================================

    public Certificate getCertificateById(
            String certificateId) throws Exception {

        String sql =
                "SELECT certificate_id, student_name, course, " +
                "college, issue_date, certificate_hash, " +
                "block_hash, previous_hash, block_number, " +
                "block_timestamp " +
                "FROM public.certificates " +
                "WHERE certificate_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    certificateId
            );

            try (
                    ResultSet resultSet =
                            statement.executeQuery()
            ) {

                if (resultSet.next()) {

                    Certificate certificate =
                            new Certificate();

                    certificate.setCertificateId(
                            resultSet.getString(
                                    "certificate_id"
                            )
                    );

                    certificate.setStudentName(
                            resultSet.getString(
                                    "student_name"
                            )
                    );

                    certificate.setCourse(
                            resultSet.getString(
                                    "course"
                            )
                    );

                    certificate.setCollege(
                            resultSet.getString(
                                    "college"
                            )
                    );

                    certificate.setIssueDate(
                            resultSet.getString(
                                    "issue_date"
                            )
                    );

                    certificate.setCertificateHash(
                            resultSet.getString(
                                    "certificate_hash"
                            )
                    );

                    certificate.setBlockHash(
                            resultSet.getString(
                                    "block_hash"
                            )
                    );

                    certificate.setPreviousHash(
                            resultSet.getString(
                                    "previous_hash"
                            )
                    );

                    certificate.setBlockNumber(
                            resultSet.getInt(
                                    "block_number"
                            )
                    );

                    certificate.setBlockTimestamp(
                            resultSet.getString(
                                    "block_timestamp"
                            )
                    );

                    return certificate;
                }
            }
        }

        return null;
    }


    // =========================================================
    // GET NEXT CERTIFICATE NUMBER
    // =========================================================

    public int getNextCertificateNumber()
            throws Exception {

        String sql =
                "SELECT COALESCE(" +
                "MAX(CAST(" +
                "SUBSTRING(certificate_id FROM 11) " +
                "AS INTEGER)), 0) + 1 AS next_number " +
                "FROM public.certificates " +
                "WHERE certificate_id LIKE 'CERT-2026-%'";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            if (resultSet.next()) {

                return resultSet.getInt(
                        "next_number"
                );
            }
        }

        return 1;
    }


    // =========================================================
    // GET NEXT BLOCK NUMBER
    // =========================================================

    public int getNextBlockNumber()
            throws Exception {

        String sql =
                "SELECT COALESCE(MAX(block_number), 0) + 1 " +
                "AS next_block_number " +
                "FROM public.certificates " +
                "WHERE block_number IS NOT NULL";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            if (resultSet.next()) {

                return resultSet.getInt(
                        "next_block_number"
                );
            }
        }

        return 1;
    }


    // =========================================================
    // GET LATEST BLOCKCHAIN CERTIFICATE
    // =========================================================

    public Certificate getLatestBlockchainCertificate()
            throws Exception {

        String sql =
                "SELECT certificate_id, student_name, course, " +
                "college, issue_date, certificate_hash, " +
                "block_hash, previous_hash, block_number, " +
                "block_timestamp " +
                "FROM public.certificates " +
                "WHERE block_number IS NOT NULL " +
                "ORDER BY block_number DESC " +
                "LIMIT 1";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            if (resultSet.next()) {

                return mapCertificate(resultSet);
            }
        }

        return null;
    }


    // =========================================================
    // GET CERTIFICATE BY BLOCK NUMBER
    // =========================================================

    public Certificate getCertificateByBlockNumber(
            int blockNumber) throws Exception {

        String sql =
                "SELECT certificate_id, student_name, course, " +
                "college, issue_date, certificate_hash, " +
                "block_hash, previous_hash, block_number, " +
                "block_timestamp " +
                "FROM public.certificates " +
                "WHERE block_number = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    blockNumber
            );

            try (
                    ResultSet resultSet =
                            statement.executeQuery()
            ) {

                if (resultSet.next()) {

                    return mapCertificate(resultSet);
                }
            }
        }

        return null;
    }


    // =========================================================
    // COUNT CERTIFICATES FOR USER
    // =========================================================

    public int getCertificateCountByUser(
            long userId) throws Exception {

        String sql =
                "SELECT COUNT(*) " +
                "FROM public.certificates " +
                "WHERE user_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setLong(
                    1,
                    userId
            );

            try (
                    ResultSet resultSet =
                            statement.executeQuery()
            ) {

                if (resultSet.next()) {

                    return resultSet.getInt(1);
                }
            }
        }

        return 0;
    }


    // =========================================================
    // MAP RESULT SET TO CERTIFICATE
    // =========================================================

    private Certificate mapCertificate(
            ResultSet resultSet) throws Exception {

        Certificate certificate =
                new Certificate();

        certificate.setCertificateId(
                resultSet.getString(
                        "certificate_id"
                )
        );

        certificate.setStudentName(
                resultSet.getString(
                        "student_name"
                )
        );

        certificate.setCourse(
                resultSet.getString(
                        "course"
                )
        );

        certificate.setCollege(
                resultSet.getString(
                        "college"
                )
        );

        certificate.setIssueDate(
                resultSet.getString(
                        "issue_date"
                )
        );

        certificate.setCertificateHash(
                resultSet.getString(
                        "certificate_hash"
                )
        );

        certificate.setBlockHash(
                resultSet.getString(
                        "block_hash"
                )
        );

        certificate.setPreviousHash(
                resultSet.getString(
                        "previous_hash"
                )
        );

        certificate.setBlockNumber(
                resultSet.getInt(
                        "block_number"
                )
        );

        certificate.setBlockTimestamp(
                resultSet.getString(
                        "block_timestamp"
                )
        );

        return certificate;
    }
}