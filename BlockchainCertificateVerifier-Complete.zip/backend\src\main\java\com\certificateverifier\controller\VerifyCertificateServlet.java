package com.certificateverifier.controller;

import com.certificateverifier.model.Certificate;
import com.certificateverifier.service.CertificateService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/verify")
public class VerifyCertificateServlet extends HttpServlet {

    private CertificateService certificateService;

    @Override
    public void init() throws ServletException {
        certificateService = new CertificateService();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String certificateId = request.getParameter("id");

        if (certificateId == null || certificateId.trim().isEmpty()) {
            certificateId = request.getParameter("certificateId");
        }

        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        if (certificateId == null || certificateId.trim().isEmpty()) {

            response.getWriter().write(
                    buildMessagePage(
                            "Certificate ID Required",
                            "Please provide a valid Certificate ID.",
                            false
                    )
            );

            return;
        }

        certificateId = certificateId.trim();

        try {

            Certificate certificate =
                    certificateService.getCertificate(certificateId);

            // Certificate does not exist
            if (certificate == null) {

                response.getWriter().write(
                        buildMessagePage(
                                "Certificate Not Found",
                                "The certificate ID <b>"
                                        + escapeHtml(certificateId)
                                        + "</b> does not exist. "
                                        + "Please check the Certificate ID and try again.",
                                false
                        )
                );

                return;
            }

            // Check complete blockchain
            boolean blockchainValid =
                    certificateService.isBlockchainValid();

            // Check individual certificate
            boolean certificateValid =
                    certificateService.isCertificateValid(certificate);

            boolean verified =
                    blockchainValid && certificateValid;

            if (verified) {

                response.getWriter().write(
                        buildVerifiedPage(certificate)
                );

            } else {

                response.getWriter().write(
                        buildMessagePage(
                                "Verification Failed",
                                "The certificate was found, but its "
                                        + "cryptographic or blockchain integrity "
                                        + "check failed. The certificate should "
                                        + "not be considered valid.",
                                false
                        )
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.getWriter().write(
                    buildMessagePage(
                            "Verification Error",
                            "An error occurred while verifying the certificate. "
                                    + "Please try again.",
                            false
                    )
            );
        }
    }

    // ============================================================
    // VERIFIED PAGE
    // ============================================================

    private String buildVerifiedPage(
            Certificate certificate) {

        String certificateId =
                safe(certificate.getCertificateId());

        String studentName =
                safe(certificate.getStudentName());

        String course =
                safe(certificate.getCourse());

        String college =
                safe(certificate.getCollege());

        String issueDate =
                safe(certificate.getIssueDate());

        String certificateHash =
                safe(certificate.getCertificateHash());

        String blockHash =
                safe(certificate.getBlockHash());

        String previousHash =
                safe(certificate.getPreviousHash());

        String blockNumber =
                String.valueOf(certificate.getBlockNumber());

        String blockTimestamp =
                safe(certificate.getBlockTimestamp());

        return "<!DOCTYPE html>"
                + "<html lang='en'>"

                + "<head>"

                + "<meta charset='UTF-8'>"

                + "<meta name='viewport' "
                + "content='width=device-width, initial-scale=1.0'>"

                + "<title>Certificate Verified | CertiChain</title>"

                + "<style>"

                + ":root{"
                + "--bg:#f4f6f9;"
                + "--surface:#ffffff;"
                + "--surface-soft:#f8fafc;"
                + "--text:#172033;"
                + "--text-secondary:#667085;"
                + "--border:#e2e6ec;"
                + "--primary:#2563eb;"
                + "--success:#16a34a;"
                + "--success-bg:#ecfdf3;"
                + "--header:#ffffff;"
                + "--shadow:0 12px 35px rgba(15,23,42,.08);"
                + "}"

                + "body.dark-theme{"
                + "--bg:#0b1120;"
                + "--surface:#111827;"
                + "--surface-soft:#172033;"
                + "--text:#f1f5f9;"
                + "--text-secondary:#a7b1c2;"
                + "--border:#263247;"
                + "--primary:#3b82f6;"
                + "--success:#22c55e;"
                + "--success-bg:#10271b;"
                + "--header:#0f172a;"
                + "--shadow:0 18px 45px rgba(0,0,0,.28);"
                + "}"

                + "*{"
                + "box-sizing:border-box;"
                + "}"

                + "body{"
                + "margin:0;"
                + "font-family:Arial,Helvetica,sans-serif;"
                + "background:var(--bg);"
                + "color:var(--text);"
                + "min-height:100vh;"
                + "transition:background .25s ease,color .25s ease;"
                + "}"

                + ".header{"
                + "height:76px;"
                + "background:var(--header);"
                + "border-bottom:1px solid var(--border);"
                + "display:flex;"
                + "align-items:center;"
                + "}"

                + ".header-inner{"
                + "width:100%;"
                + "max-width:1180px;"
                + "margin:auto;"
                + "padding:0 28px;"
                + "display:flex;"
                + "align-items:center;"
                + "justify-content:space-between;"
                + "}"

                + ".brand{"
                + "display:flex;"
                + "align-items:center;"
                + "gap:11px;"
                + "text-decoration:none;"
                + "color:var(--text);"
                + "font-size:23px;"
                + "font-weight:700;"
                + "}"

                + ".brand-mark{"
                + "width:36px;"
                + "height:36px;"
                + "border-radius:9px;"
                + "background:var(--primary);"
                + "color:white;"
                + "display:flex;"
                + "align-items:center;"
                + "justify-content:center;"
                + "font-size:19px;"
                + "font-weight:700;"
                + "}"

                + ".nav{"
                + "display:flex;"
                + "align-items:center;"
                + "gap:28px;"
                + "}"

                + ".nav a{"
                + "color:var(--text-secondary);"
                + "text-decoration:none;"
                + "font-size:14px;"
                + "font-weight:600;"
                + "}"

                + ".nav a:hover{"
                + "color:var(--primary);"
                + "}"

                + ".theme-toggle{"
                + "width:40px;"
                + "height:40px;"
                + "border:1px solid var(--border);"
                + "background:var(--surface);"
                + "color:var(--text);"
                + "border-radius:9px;"
                + "cursor:pointer;"
                + "font-size:17px;"
                + "}"

                + ".page{"
                + "max-width:900px;"
                + "margin:auto;"
                + "padding:60px 24px 80px;"
                + "}"

                + ".status-header{"
                + "text-align:center;"
                + "margin-bottom:34px;"
                + "}"

                + ".status-icon{"
                + "width:72px;"
                + "height:72px;"
                + "margin:0 auto 20px;"
                + "border-radius:50%;"
                + "background:var(--success-bg);"
                + "color:var(--success);"
                + "display:flex;"
                + "align-items:center;"
                + "justify-content:center;"
                + "font-size:38px;"
                + "font-weight:700;"
                + "}"

                + ".status-header h1{"
                + "margin:0 0 10px;"
                + "font-size:34px;"
                + "}"

                + ".status-header p{"
                + "margin:0;"
                + "color:var(--text-secondary);"
                + "font-size:16px;"
                + "line-height:1.6;"
                + "}"

                + ".card{"
                + "background:var(--surface);"
                + "border:1px solid var(--border);"
                + "border-radius:18px;"
                + "box-shadow:var(--shadow);"
                + "padding:34px;"
                + "}"

                + ".verified-banner{"
                + "display:flex;"
                + "align-items:center;"
                + "gap:12px;"
                + "padding:16px 18px;"
                + "margin-bottom:25px;"
                + "border:1px solid rgba(22,163,74,.25);"
                + "background:var(--success-bg);"
                + "border-radius:12px;"
                + "color:var(--success);"
                + "font-size:15px;"
                + "font-weight:700;"
                + "}"

                + ".verified-dot{"
                + "width:9px;"
                + "height:9px;"
                + "border-radius:50%;"
                + "background:var(--success);"
                + "}"

                + ".details{"
                + "display:grid;"
                + "gap:12px;"
                + "}"

                + ".row{"
                + "padding:18px;"
                + "background:var(--surface-soft);"
                + "border:1px solid var(--border);"
                + "border-radius:10px;"
                + "}"

                + ".label{"
                + "font-size:12px;"
                + "font-weight:700;"
                + "letter-spacing:.05em;"
                + "text-transform:uppercase;"
                + "color:var(--text-secondary);"
                + "margin-bottom:7px;"
                + "}"

                + ".value{"
                + "font-size:15px;"
                + "font-weight:600;"
                + "color:var(--text);"
                + "line-height:1.5;"
                + "word-break:break-word;"
                + "}"

                + ".hash-value{"
                + "font-family:'Courier New',monospace;"
                + "font-size:13px;"
                + "line-height:1.6;"
                + "word-break:break-all;"
                + "}"

                + ".footer-note{"
                + "margin-top:25px;"
                + "padding:16px;"
                + "border-radius:10px;"
                + "background:var(--surface-soft);"
                + "border:1px solid var(--border);"
                + "color:var(--text-secondary);"
                + "font-size:13px;"
                + "line-height:1.6;"
                + "text-align:center;"
                + "}"

                + "@media(max-width:700px){"

                + ".header-inner{"
                + "padding:14px 18px;"
                + "}"

                + ".nav{"
                + "gap:12px;"
                + "}"

                + ".nav a{"
                + "display:none;"
                + "}"

                + ".page{"
                + "padding:40px 15px 60px;"
                + "}"

                + ".status-header h1{"
                + "font-size:28px;"
                + "}"

                + ".card{"
                + "padding:20px;"
                + "}"

                + "}"

                + "</style>"

                + "</head>"

                + "<body>"

                + "<header class='header'>"

                + "<div class='header-inner'>"

                + "<a class='brand' href='dashboard'>"
                + "<span class='brand-mark'>C</span>"
                + "CertiChain"
                + "</a>"

                + "<nav class='nav'>"

                + "<a href='dashboard'>Home</a>"

                + "<a href='issue.html'>Issue Certificate</a>"

                + "<a href='verify.html'>Verify</a>"

                + "<button type='button' "
                + "class='theme-toggle' "
                + "id='themeToggle'>🌙</button>"

                + "</nav>"

                + "</div>"

                + "</header>"

                + "<main class='page'>"

                + "<div class='status-header'>"

                + "<div class='status-icon'>✓</div>"

                + "<h1>Certificate Verified</h1>"

                + "<p>"
                + "This certificate is authentic and the blockchain "
                + "integrity check passed."
                + "</p>"

                + "</div>"

                + "<div class='card'>"

                + "<div class='verified-banner'>"
                + "<span class='verified-dot'></span>"
                + "Certificate authenticity verified successfully"
                + "</div>"

                + "<div class='details'>"

                + detail(
                        "Certificate ID",
                        certificateId,
                        false
                )

                + detail(
                        "Student Name",
                        studentName,
                        false
                )

                + detail(
                        "Course",
                        course,
                        false
                )

                + detail(
                        "College",
                        college,
                        false
                )

                + detail(
                        "Issue Date",
                        issueDate,
                        false
                )

                + detail(
                        "Certificate Hash",
                        certificateHash,
                        true
                )

                + detail(
                        "Blockchain Block Hash",
                        blockHash,
                        true
                )

                + detail(
                        "Previous Block Hash",
                        previousHash,
                        true
                )

                + detail(
                        "Block Number",
                        blockNumber,
                        false
                )

                + detail(
                        "Block Timestamp",
                        blockTimestamp,
                        false
                )

                + "</div>"

                + "<div class='footer-note'>"
                + "CertiChain verified the certificate using SHA-256 "
                + "hashing and blockchain integrity validation."
                + "</div>"

                + "</div>"

                + "</main>"

                + "<script>"

                + "const savedTheme = "
                + "localStorage.getItem('certichain-theme');"

                + "if(savedTheme === 'dark'){"
                + "document.body.classList.add('dark-theme');"
                + "}"

                + "const toggle = "
                + "document.getElementById('themeToggle');"

                + "function updateIcon(){"
                + "toggle.textContent = "
                + "document.body.classList.contains('dark-theme') "
                + "? '☀️' : '🌙';"
                + "}"

                + "updateIcon();"

                + "toggle.addEventListener('click', function(){"

                + "document.body.classList.toggle('dark-theme');"

                + "const dark = "
                + "document.body.classList.contains('dark-theme');"

                + "localStorage.setItem("
                + "'certichain-theme',"
                + "dark ? 'dark' : 'light'"
                + ");"

                + "updateIcon();"

                + "});"

                + "</script>"

                + "</body>"

                + "</html>";
    }

    // ============================================================
    // MESSAGE PAGE
    // ============================================================

    private String buildMessagePage(
            String title,
            String message,
            boolean success) {

        String icon =
                success ? "✓" : "×";

        String color =
                success ? "#16a34a" : "#dc2626";

        return "<!DOCTYPE html>"

                + "<html lang='en'>"

                + "<head>"

                + "<meta charset='UTF-8'>"

                + "<meta name='viewport' "
                + "content='width=device-width, initial-scale=1.0'>"

                + "<title>"
                + escapeHtml(title)
                + " | CertiChain</title>"

                + "<style>"

                + ":root{"
                + "--bg:#f4f6f9;"
                + "--surface:#ffffff;"
                + "--text:#172033;"
                + "--secondary:#667085;"
                + "--border:#e2e6ec;"
                + "--header:#ffffff;"
                + "}"

                + "body.dark-theme{"
                + "--bg:#0b1120;"
                + "--surface:#111827;"
                + "--text:#f1f5f9;"
                + "--secondary:#a7b1c2;"
                + "--border:#263247;"
                + "--header:#0f172a;"
                + "}"

                + "*{box-sizing:border-box;}"

                + "body{"
                + "margin:0;"
                + "font-family:Arial,Helvetica,sans-serif;"
                + "background:var(--bg);"
                + "color:var(--text);"
                + "min-height:100vh;"
                + "}"

                + ".header{"
                + "height:76px;"
                + "background:var(--header);"
                + "border-bottom:1px solid var(--border);"
                + "display:flex;"
                + "align-items:center;"
                + "}"

                + ".header-inner{"
                + "width:100%;"
                + "max-width:1180px;"
                + "margin:auto;"
                + "padding:0 28px;"
                + "display:flex;"
                + "justify-content:space-between;"
                + "align-items:center;"
                + "}"

                + ".brand{"
                + "text-decoration:none;"
                + "color:var(--text);"
                + "font-size:23px;"
                + "font-weight:700;"
                + "}"

                + ".brand-mark{"
                + "display:inline-flex;"
                + "width:36px;"
                + "height:36px;"
                + "margin-right:10px;"
                + "border-radius:9px;"
                + "background:#2563eb;"
                + "color:white;"
                + "align-items:center;"
                + "justify-content:center;"
                + "}"

                + ".theme-toggle{"
                + "width:40px;"
                + "height:40px;"
                + "border:1px solid var(--border);"
                + "background:var(--surface);"
                + "border-radius:9px;"
                + "cursor:pointer;"
                + "}"

                + ".page{"
                + "min-height:calc(100vh - 76px);"
                + "display:flex;"
                + "align-items:center;"
                + "justify-content:center;"
                + "padding:30px;"
                + "}"

                + ".card{"
                + "max-width:700px;"
                + "width:100%;"
                + "background:var(--surface);"
                + "border:1px solid var(--border);"
                + "border-radius:18px;"
                + "padding:55px 40px;"
                + "text-align:center;"
                + "box-shadow:0 12px 35px rgba(15,23,42,.08);"
                + "}"

                + ".icon{"
                + "width:72px;"
                + "height:72px;"
                + "margin:0 auto 22px;"
                + "border-radius:50%;"
                + "background:"
                + color
                + "22;"
                + "color:"
                + color
                + ";"
                + "font-size:42px;"
                + "display:flex;"
                + "align-items:center;"
                + "justify-content:center;"
                + "font-weight:700;"
                + "}"

                + "h1{"
                + "margin:0 0 12px;"
                + "font-size:32px;"
                + "}"

                + "p{"
                + "color:var(--secondary);"
                + "font-size:16px;"
                + "line-height:1.7;"
                + "margin:0;"
                + "}"

                + "</style>"

                + "</head>"

                + "<body>"

                + "<header class='header'>"

                + "<div class='header-inner'>"

                + "<a class='brand' href='dashboard'>"
                + "<span class='brand-mark'>C</span>"
                + "CertiChain"
                + "</a>"

                + "<button class='theme-toggle' "
                + "id='themeToggle'>🌙</button>"

                + "</div>"

                + "</header>"

                + "<main class='page'>"

                + "<div class='card'>"

                + "<div class='icon'>"
                + icon
                + "</div>"

                + "<h1>"
                + escapeHtml(title)
                + "</h1>"

                + "<p>"
                + message
                + "</p>"

                + "</div>"

                + "</main>"

                + "<script>"

                + "const savedTheme = "
                + "localStorage.getItem('certichain-theme');"

                + "if(savedTheme === 'dark'){"
                + "document.body.classList.add('dark-theme');"
                + "}"

                + "const toggle = "
                + "document.getElementById('themeToggle');"

                + "toggle.textContent = "
                + "document.body.classList.contains('dark-theme') "
                + "? '☀️' : '🌙';"

                + "toggle.addEventListener('click',function(){"

                + "document.body.classList.toggle('dark-theme');"

                + "const dark = "
                + "document.body.classList.contains('dark-theme');"

                + "localStorage.setItem("
                + "'certichain-theme',"
                + "dark ? 'dark' : 'light'"
                + ");"

                + "toggle.textContent = dark ? '☀️' : '🌙';"

                + "});"

                + "</script>"

                + "</body>"

                + "</html>";
    }

    // ============================================================
    // DETAIL ROW
    // ============================================================

    private String detail(
            String label,
            String value,
            boolean hash) {

        String cssClass =
                hash ? "value hash-value" : "value";

        return "<div class='row'>"
                + "<div class='label'>"
                + escapeHtml(label)
                + "</div>"
                + "<div class='"
                + cssClass
                + "'>"
                + escapeHtml(value)
                + "</div>"
                + "</div>";
    }

    // ============================================================
    // SAFE STRING
    // ============================================================

    private String safe(String value) {

        if (value == null ||
                value.trim().isEmpty()) {

            return "Not available";
        }

        return value;
    }

    // ============================================================
    // HTML ESCAPE
    // ============================================================

    private String escapeHtml(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}