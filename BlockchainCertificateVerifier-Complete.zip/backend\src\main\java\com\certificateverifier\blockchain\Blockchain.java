package com.certificateverifier.blockchain;

import java.util.ArrayList;
import java.util.List;

public class Blockchain {

    private List<Block> chain;

    public Blockchain() {
        chain = new ArrayList<>();
    }

    public void addBlock(Block block) {
        chain.add(block);
    }

    public List<Block> getChain() {
        return chain;
    }

    public Block getLatestBlock() {
        if (chain.isEmpty()) {
            return null;
        }

        return chain.get(chain.size() - 1);
    }

    public boolean isChainValid() {

        for (int i = 1; i < chain.size(); i++) {

            Block currentBlock = chain.get(i);
            Block previousBlock = chain.get(i - 1);

            if (!currentBlock.getBlockHash()
                    .equals(currentBlock.calculateHash())) {
                return false;
            }

            if (!currentBlock.getPreviousHash()
                    .equals(previousBlock.getBlockHash())) {
                return false;
            }
        }

        return true;
    }
}